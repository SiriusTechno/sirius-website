import { useState } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { TranslationContext, translations, type Language } from "./lib/i18n";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [language, setLanguage] = useState<Language>('fr');

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations[typeof language]] || key;
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TranslationContext.Provider value={{ language, setLanguage, t }}>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </TranslationContext.Provider>
    </QueryClientProvider>
  );
}

export default App;

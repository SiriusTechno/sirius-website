import { createContext, useContext } from 'react';

export type Language = 'en' | 'fr';

export interface TranslationContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

export const TranslationContext = createContext<TranslationContextType | undefined>(undefined);

export const useTranslation = () => {
  const context = useContext(TranslationContext);
  if (!context) {
    throw new Error('useTranslation must be used within a TranslationProvider');
  }
  return context;
};

export const translations = {
  en: {
    // Navigation
    'nav.home': 'Home',
    'nav.services': 'Services',
    'nav.about': 'About',
    'nav.portfolio': 'Portfolio',
    'nav.contact': 'Contact',
    
    // Hero Section
    'hero.title1': 'Innovative Tech',
    'hero.title2': 'Solutions',
    'hero.subtitle': 'We transform businesses through cutting-edge mobile development, ERP solutions, and AI-powered analytics.',
    'hero.cta.primary': 'Get Started',
    'hero.cta.secondary': 'View Portfolio',
    'hero.stat.projects': 'Projects Completed',
    'hero.stat.experience': 'Years Experience',
    'hero.stat.clients': 'Happy Clients',
    'hero.stat.support': 'Support',
    
    // Services
    'services.title': 'Our Services',
    'services.subtitle': 'We provide comprehensive technology solutions to help your business thrive in the digital age.',
    'services.mobile.title': 'Mobile & Web Development',
    'services.mobile.description': 'Custom mobile applications and responsive websites built with cutting-edge technologies for optimal performance and user experience.',
    'services.mobile.feature1': 'iOS & Android Apps',
    'services.mobile.feature2': 'Progressive Web Apps',
    'services.mobile.feature3': 'E-commerce Solutions',
    'services.erp.title': 'ERP Business Applications',
    'services.erp.description': 'Streamline your business operations with custom ERP solutions designed to integrate all aspects of your organization efficiently.',
    'services.erp.feature1': 'Resource Planning',
    'services.erp.feature2': 'Inventory Management',
    'services.erp.feature3': 'Financial Integration',
    'services.ai.title': 'AI & Big Data Analytics',
    'services.ai.description': 'Harness the power of artificial intelligence and big data to gain valuable insights and automate complex business processes.',
    'services.ai.feature1': 'Machine Learning',
    'services.ai.feature2': 'Predictive Analytics',
    'services.ai.feature3': 'Data Visualization',
    
    // About
    'about.title': 'Why Choose SIRIUS?',
    'about.subtitle': "We're a team of passionate technologists dedicated to delivering innovative solutions that drive business success and digital transformation.",
    'about.innovation.title': 'Innovation First',
    'about.innovation.description': 'We stay ahead of technology trends to deliver cutting-edge solutions.',
    'about.team.title': 'Expert Team',
    'about.team.description': 'Our experienced developers and consultants bring deep industry knowledge.',
    'about.delivery.title': 'Timely Delivery',
    'about.delivery.description': 'We understand the importance of deadlines and deliver on time, every time.',
    
    // Portfolio
    'portfolio.title': 'Our Portfolio',
    'portfolio.subtitle': "Explore some of our recent projects and see how we've helped businesses transform through technology.",
    'portfolio.viewAll': 'View All Projects',
    'portfolio.item1.title': 'Mobile Application',
    'portfolio.item1.category': 'iOS & Android',
    'portfolio.item2.title': 'ERP Dashboard',
    'portfolio.item2.category': 'Business Intelligence',
    'portfolio.item3.title': 'AI Platform',
    'portfolio.item3.category': 'Machine Learning',
    'portfolio.item4.title': 'Construction ERP',
    'portfolio.item4.category': 'React & Node.js',
    'portfolio.item5.title': 'Healthcare Platform',
    'portfolio.item5.category': 'Custom ERP',
    'portfolio.item6.title': 'Data Management',
    'portfolio.item6.category': 'AI & Big Data',
    'portfolio.viewClients': 'Our Clients',
    
    // Clients
    'clients.title': 'They Trusted Us',
    'clients.subtitle': 'We are proud to work with leading companies and organizations across various industries.',
    
    // Contact
    'contact.title': 'Get In Touch',
    'contact.subtitle': "Ready to transform your business? Let's discuss your project and create something amazing together.",
    'contact.info.title': 'Contact Information',
    'contact.info.phone': 'Phone Numbers',
    'contact.info.email': 'Email Address',
    'contact.info.hours': 'Business Hours',
    'contact.info.hoursValue': 'Mon - Fri: 8:00 AM - 6:00 PM',
    'contact.social.title': 'Follow Us',
    'contact.form.title': 'Send Us a Message',
    'contact.form.firstName': 'First Name',
    'contact.form.lastName': 'Last Name',
    'contact.form.email': 'Email',
    'contact.form.service': 'Service Needed',
    'contact.form.serviceSelect': 'Select a service',
    'contact.form.serviceMobile': 'Mobile & Web Development',
    'contact.form.serviceErp': 'ERP Solutions',
    'contact.form.serviceAi': 'AI & Big Data',
    'contact.form.message': 'Message',
    'contact.form.messagePlaceholder': 'Tell us about your project...',
    'contact.form.submit': 'Send Message',
    'contact.form.success': 'Thank you for your message! We will get back to you soon.',
    'contact.form.error': 'There was an error sending your message. Please try again.',
    
    // Footer
    'footer.services': 'Services',
    'footer.company': 'Company',
    'footer.contactInfo': 'Contact Info',
    'footer.copyright': '© 2024 SIRIUS Technologies. All rights reserved.',
  },
  fr: {
    // Navigation
    'nav.home': 'Accueil',
    'nav.services': 'Services',
    'nav.about': 'À Propos',
    'nav.portfolio': 'Portfolio',
    'nav.contact': 'Contact',
    
    // Hero Section
    'hero.title1': 'Technologies',
    'hero.title2': 'Innovantes',
    'hero.subtitle': 'Nous transformons les entreprises grâce au développement mobile, aux solutions ERP et à l\'analytique IA.',
    'hero.cta.primary': 'Commencer',
    'hero.cta.secondary': 'Voir Portfolio',
    'hero.stat.projects': 'Projets Réalisés',
    'hero.stat.experience': 'Années d\'Expérience',
    'hero.stat.clients': 'Clients Satisfaits',
    'hero.stat.support': 'Support',
    
    // Services
    'services.title': 'Nos Services',
    'services.subtitle': 'Nous fournissons des solutions technologiques complètes pour aider votre entreprise à prospérer à l\'ère numérique.',
    'services.mobile.title': 'Développement Mobile & Web',
    'services.mobile.description': 'Applications mobiles personnalisées et sites web réactifs construits avec des technologies de pointe pour des performances optimales.',
    'services.mobile.feature1': 'Apps iOS & Android',
    'services.mobile.feature2': 'Applications Web Progressives',
    'services.mobile.feature3': 'Solutions E-commerce',
    'services.erp.title': 'Applications Métiers ERP',
    'services.erp.description': 'Rationalisez vos opérations commerciales avec des solutions ERP personnalisées conçues pour intégrer tous les aspects de votre organisation.',
    'services.erp.feature1': 'Planification des Ressources',
    'services.erp.feature2': 'Gestion d\'Inventaire',
    'services.erp.feature3': 'Intégration Financière',
    'services.ai.title': 'IA & Analyse Big Data',
    'services.ai.description': 'Exploitez la puissance de l\'intelligence artificielle et du big data pour obtenir des insights précieux et automatiser les processus métiers complexes.',
    'services.ai.feature1': 'Apprentissage Automatique',
    'services.ai.feature2': 'Analyse Prédictive',
    'services.ai.feature3': 'Visualisation de Données',
    
    // About
    'about.title': 'Pourquoi Choisir SIRIUS?',
    'about.subtitle': 'Nous sommes une équipe de technologues passionnés dédiés à la livraison de solutions innovantes qui favorisent le succès commercial et la transformation numérique.',
    'about.innovation.title': 'Innovation d\'Abord',
    'about.innovation.description': 'Nous restons à l\'avant-garde des tendances technologiques pour livrer des solutions de pointe.',
    'about.team.title': 'Équipe d\'Experts',
    'about.team.description': 'Nos développeurs expérimentés et consultants apportent une connaissance approfondie de l\'industrie.',
    'about.delivery.title': 'Livraison Ponctuelle',
    'about.delivery.description': 'Nous comprenons l\'importance des délais et livrons à temps, à chaque fois.',
    
    // Portfolio
    'portfolio.title': 'Notre Portfolio',
    'portfolio.subtitle': 'Explorez quelques-uns de nos projets récents et voyez comment nous avons aidé les entreprises à se transformer grâce à la technologie.',
    'portfolio.viewAll': 'Voir Tous les Projets',
    'portfolio.item1.title': 'Application Mobile',
    'portfolio.item1.category': 'iOS & Android',
    'portfolio.item2.title': 'Tableau de bord ERP',
    'portfolio.item2.category': 'Business Intelligence',
    'portfolio.item3.title': 'Plateforme IA',
    'portfolio.item3.category': 'Machine Learning',
    'portfolio.item4.title': 'ERP pour entreprises du BTP',
    'portfolio.item4.category': 'React & Node.js',
    'portfolio.item5.title': 'Plateforme pour la santé',
    'portfolio.item5.category': 'Custom ERP',
    'portfolio.item6.title': 'Gestion des données',
    'portfolio.item6.category': 'AI & Big Data',
    'portfolio.viewClients': 'Nos Clients',
    
    // Clients
    'clients.title': 'Ils nous ont fait confiance',
    'clients.subtitle': 'Nous sommes fiers de travailler avec des entreprises et organisations leaders dans divers secteurs.',
    
    // Contact
    'contact.title': 'Contactez-Nous',
    'contact.subtitle': 'Prêt à transformer votre entreprise? Discutons de votre projet et créons quelque chose d\'extraordinaire ensemble.',
    'contact.info.title': 'Informations de Contact',
    'contact.info.phone': 'Numéros de Téléphone',
    'contact.info.email': 'Adresse Email',
    'contact.info.hours': 'Heures d\'Ouverture',
    'contact.info.hoursValue': 'Lun - Ven: 8h00 - 18h00',
    'contact.social.title': 'Suivez-Nous',
    'contact.form.title': 'Envoyez-nous un Message',
    'contact.form.firstName': 'Prénom',
    'contact.form.lastName': 'Nom',
    'contact.form.email': 'Email',
    'contact.form.service': 'Service Requis',
    'contact.form.serviceSelect': 'Sélectionner un service',
    'contact.form.serviceMobile': 'Développement Mobile & Web',
    'contact.form.serviceErp': 'Solutions ERP',
    'contact.form.serviceAi': 'IA & Big Data',
    'contact.form.message': 'Message',
    'contact.form.messagePlaceholder': 'Parlez-nous de votre projet...',
    'contact.form.submit': 'Envoyer le Message',
    'contact.form.success': 'Merci pour votre message! Nous vous recontacterons bientôt.',
    'contact.form.error': 'Il y a eu une erreur lors de l\'envoi de votre message. Veuillez réessayer.',
    
    // Footer
    'footer.services': 'Services',
    'footer.company': 'Entreprise',
    'footer.contactInfo': 'Infos Contact',
    'footer.copyright': '© 2024 SIRIUS Technologies. Tous droits réservés.',
  }
};

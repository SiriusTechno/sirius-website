import { motion } from 'framer-motion';
import { Smartphone, Settings, Brain, Check, Code, Database, BarChart3 } from 'lucide-react';
import { useTranslation } from '@/lib/i18n';
import { useIntersectionObserver } from '@/hooks/useIntersectionObserver';

export function Services() {
  const { t } = useTranslation();
  const { ref, isIntersecting } = useIntersectionObserver();

  const services = [
    {
      icon: Code,
      title: t('services.mobile.title'),
      description: t('services.mobile.description'),
      features: [
        t('services.mobile.feature1'),
        t('services.mobile.feature2'),
        t('services.mobile.feature3'),
      ],
      gradient: 'from-[hsl(var(--sirius-primary-500))] to-[hsl(var(--sirius-primary-600))]',
    },
    {
      icon: Database,
      title: t('services.erp.title'),
      description: t('services.erp.description'),
      features: [
        t('services.erp.feature1'),
        t('services.erp.feature2'),
        t('services.erp.feature3'),
      ],
      gradient: 'from-[hsl(var(--sirius-accent-500))] to-[hsl(var(--sirius-accent-600))]',
    },
    {
      icon: BarChart3,
      title: t('services.ai.title'),
      description: t('services.ai.description'),
      features: [
        t('services.ai.feature1'),
        t('services.ai.feature2'),
        t('services.ai.feature3'),
      ],
      gradient: 'from-[hsl(var(--sirius-primary-600))] to-[hsl(var(--sirius-accent-500))]',
    },
  ];

  return (
    <section id="services" className="py-20 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isIntersecting ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            {t('services.title')}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {t('services.subtitle')}
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100"
              initial={{ opacity: 0, y: 50 }}
              animate={isIntersecting ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.2 }}
            >
              <div className={`w-24 h-24 rounded-3xl flex items-center justify-center mb-6 group-hover:scale-110 transition-all duration-300 shadow-xl ${
                index === 0 ? 'bg-blue-50' : index === 1 ? 'bg-cyan-50' : 'bg-indigo-50'
              }`}>
                <service.icon className={`w-12 h-12 drop-shadow-lg ${
                  index === 0 ? 'text-blue-600' : index === 1 ? 'text-cyan-600' : 'text-indigo-600'
                }`} />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                {service.title}
              </h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                {service.description}
              </p>
              <ul className="space-y-2 text-sm text-gray-500">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center">
                    <Check className="w-4 h-4 text-[hsl(var(--sirius-primary-500))] mr-2 flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

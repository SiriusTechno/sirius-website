import { motion } from 'framer-motion';
import { useIntersectionObserver } from '@/hooks/useIntersectionObserver';
import { useTranslation } from '@/lib/i18n';

export function Clients() {
  const { t } = useTranslation();
  const { ref, isIntersecting } = useIntersectionObserver();

  const clients = [
    {
      name: 'Utech',
      logo: '/attached_assets/company-1_1752052553829.png',
      alt: 'Utech logo'
    },
    {
      name: 'APM Africa Project Management',
      logo: '/attached_assets/company-2_1752052553830.png',
      alt: 'APM Africa Project Management logo'
    },
    {
      name: 'BTR Construction',
      logo: '/attached_assets/company-3_1752052553830.png',
      alt: 'BTR Construction logo'
    },
    {
      name: 'SUNU Assurances',
      logo: '/attached_assets/company-4_1752052553830.png',
      alt: 'SUNU Assurances logo'
    },
    {
      name: 'Client 5',
      logo: '/attached_assets/company-5_1752052553831.jpeg',
      alt: 'Client 5 logo'
    }
  ];

  return (
    <section id="clients" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={isIntersecting ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            {t('clients.title')}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {t('clients.subtitle')}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isIntersecting ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8 items-center"
        >
          {clients.map((client, index) => (
            <motion.div
              key={client.name}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={isIntersecting ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              className="flex items-center justify-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-all duration-300 hover:scale-105"
            >
              <img
                src={client.logo}
                alt={client.alt}
                className="max-h-16 max-w-full object-contain transition-all duration-300"
              />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
import { Button } from "@/components/ui/button";
import { useTranslation } from "@/lib/i18n";

export function LanguageSwitcher() {
  const { language, setLanguage } = useTranslation();

  return (
    <div className="fixed top-4 right-4 z-50">
      <div className="flex bg-white rounded-full shadow-lg p-1">
        <Button
          onClick={() => setLanguage('en')}
          variant={language === 'en' ? 'default' : 'ghost'}
          size="sm"
          className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
            language === 'en' 
              ? 'bg-blue-600 text-white' 
              : 'text-gray-600 hover:bg-blue-600 hover:text-white'
          }`}
        >
          EN
        </Button>
        <Button
          onClick={() => setLanguage('fr')}
          variant={language === 'fr' ? 'default' : 'ghost'}
          size="sm"
          className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
            language === 'fr' 
              ? 'bg-blue-600 text-white' 
              : 'text-gray-600 hover:bg-blue-600 hover:text-white'
          }`}
        >
          FR
        </Button>
      </div>
    </div>
  );
}

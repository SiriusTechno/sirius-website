import { motion } from 'framer-motion';
import { useTranslation } from '@/lib/i18n';
import { useIntersectionObserver } from '@/hooks/useIntersectionObserver';

export function Portfolio() {
  const { t } = useTranslation();
  const { ref, isIntersecting } = useIntersectionObserver();

  const portfolioItems = [
    {
      image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      titleKey: "portfolio.item1.title",
      categoryKey: "portfolio.item1.category",
      alt: "Mobile app development workspace showing UI design and coding"
    },
    {
      image: "https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      titleKey: "portfolio.item2.title",
      categoryKey: "portfolio.item2.category",
      alt: "Business meeting with modern technology dashboard and data visualization"
    },
    {
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      titleKey: "portfolio.item3.title",
      categoryKey: "portfolio.item3.category",
      alt: "AI and data analytics dashboard with modern charts and machine learning visualizations"
    },
    {
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      titleKey: "portfolio.item4.title",
      categoryKey: "portfolio.item4.category",
      alt: "Professional data analytics dashboard showing business metrics and performance charts"
    },
    {
      image: "https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      titleKey: "portfolio.item5.title",
      categoryKey: "portfolio.item5.category",
      alt: "Business professionals in meeting discussing technology solutions and digital transformation"
    },
    {
      image: "https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      titleKey: "portfolio.item6.title",
      categoryKey: "portfolio.item6.category",
      alt: "Advanced data analytics interface with complex visualizations and artificial intelligence elements"
    },
  ];

  return (
    <section id="portfolio" className="py-20 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isIntersecting ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            {t('portfolio.title')}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {t('portfolio.subtitle')}
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {portfolioItems.map((item, index) => (
            <motion.div
              key={index}
              className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300"
              initial={{ opacity: 0, y: 50 }}
              animate={isIntersecting ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <img 
                src={item.image}
                alt={item.alt}
                className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent"></div>
              <div className="absolute bottom-6 left-6 text-white">
                <h4 className="text-xl font-bold mb-2 drop-shadow-lg">{t(item.titleKey)}</h4>
                <p className="text-sm opacity-95 drop-shadow-md">{t(item.categoryKey)}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div 
          className="text-center mt-12"
          initial={{ opacity: 0 }}
          animate={isIntersecting ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900">
            {t('portfolio.viewClients')}
          </h2>
        </motion.div>
      </div>
    </section>
  );
}

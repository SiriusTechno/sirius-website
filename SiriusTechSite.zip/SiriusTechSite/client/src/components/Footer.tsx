import { useTranslation } from '@/lib/i18n';

export function Footer() {
  const { t } = useTranslation();

  const footerSections = [
    {
      title: t('footer.services'),
      links: [
        { label: 'Mobile Development', href: '#' },
        { label: 'Web Development', href: '#' },
        { label: 'ERP Solutions', href: '#' },
        { label: 'AI & Analytics', href: '#' },
      ],
    },
    {
      title: t('footer.company'),
      links: [
        { label: t('nav.about'), href: '#about' },
        { label: t('nav.portfolio'), href: '#portfolio' },
        { label: 'Careers', href: '#' },
        { label: t('nav.contact'), href: '#contact' },
      ],
    },
    {
      title: t('footer.contactInfo'),
      content: (
        <div className="space-y-2 text-black">
          <p>27 22 51 70 49</p>
          <p>07 07 07 01 33</p>
          <p>info@siriustechnologies.ci</p>
        </div>
      ),
    },
  ];

  const scrollToSection = (sectionId: string) => {
    if (sectionId.startsWith('#')) {
      const element = document.getElementById(sectionId.substring(1));
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  };

  return (
    <footer className="bg-white text-black py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="mb-8 flex flex-col items-center">
            <img 
              src="/attached_assets/Logo Book-02_1752007251605.png" 
              alt="SIRIUS Technologies Logo" 
              className="h-16 w-auto mb-4"
            />
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            {footerSections.map((section, index) => (
              <div key={index}>
                <h4 className="text-lg font-semibold mb-4">{section.title}</h4>
                {section.links ? (
                  <ul className="space-y-2 text-black">
                    {section.links.map((link, linkIndex) => (
                      <li key={linkIndex}>
                        <button
                          onClick={() => scrollToSection(link.href)}
                          className="hover:text-blue-600 transition-colors text-left"
                        >
                          {link.label}
                        </button>
                      </li>
                    ))}
                  </ul>
                ) : (
                  section.content
                )}
              </div>
            ))}
          </div>
          
          <div className="border-t border-gray-300 pt-8">
            <p className="text-black">
              {t('footer.copyright')}
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}

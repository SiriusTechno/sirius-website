import { motion } from 'framer-motion';
import { Rocket, Users, Clock } from 'lucide-react';
import { useTranslation } from '@/lib/i18n';
import { useIntersectionObserver } from '@/hooks/useIntersectionObserver';

export function About() {
  const { t } = useTranslation();
  const { ref, isIntersecting } = useIntersectionObserver();

  const features = [
    {
      icon: Rocket,
      title: t('about.innovation.title'),
      description: t('about.innovation.description'),
    },
    {
      icon: Users,
      title: t('about.team.title'),
      description: t('about.team.description'),
    },
    {
      icon: Clock,
      title: t('about.delivery.title'),
      description: t('about.delivery.description'),
    },
  ];

  return (
    <section id="about" className="py-20 bg-gray-50" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isIntersecting ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              {t('about.title')}
            </h2>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              {t('about.subtitle')}
            </p>
            
            <div className="space-y-6">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  className="flex items-start space-x-4"
                  initial={{ opacity: 0, y: 20 }}
                  animate={isIntersecting ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <div className="w-8 h-8 bg-[hsl(var(--sirius-primary-500))] rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <feature.icon className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">
                      {feature.title}
                    </h4>
                    <p className="text-gray-600">
                      {feature.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
          
          <motion.div 
            className="relative"
            initial={{ opacity: 0, x: 50 }}
            animate={isIntersecting ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <img 
              src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Modern technology office with collaborative team environment" 
              className="rounded-2xl shadow-xl w-full h-auto"
            />
            <motion.div 
              className="absolute -bottom-6 -left-6 w-24 h-24 bg-gradient-to-r from-[hsl(var(--sirius-primary-500))] to-[hsl(var(--sirius-accent-500))] rounded-2xl flex items-center justify-center shadow-xl"
              initial={{ scale: 0 }}
              animate={isIntersecting ? { scale: 1 } : {}}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <i className="fas fa-award text-white text-2xl"></i>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

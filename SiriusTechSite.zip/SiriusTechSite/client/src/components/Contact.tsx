import { useState } from 'react';
import { motion } from 'framer-motion';
import { Phone, Mail, Clock, Linkedin, Twitter, Github } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from '@/lib/i18n';
import { useIntersectionObserver } from '@/hooks/useIntersectionObserver';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

export function Contact() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const { ref, isIntersecting } = useIntersectionObserver();
  
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    service: '',
    message: '',
  });

  const contactMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest('POST', '/api/contact', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: t('contact.form.success'),
      });
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        service: '',
        message: '',
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: t('contact.form.error'),
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    contactMutation.mutate(formData);
  };

  const handleInputChange = (field: keyof typeof formData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const contactInfo = [
    {
      icon: Phone,
      title: t('contact.info.phone'),
      content: (
        <>
          <div>27 22 51 70 49</div>
          <div>07 07 07 01 33</div>
        </>
      ),
    },
    {
      icon: Mail,
      title: t('contact.info.email'),
      content: <div>info@siriustechnologies.ci</div>,
    },
    {
      icon: Clock,
      title: t('contact.info.hours'),
      content: <div>{t('contact.info.hoursValue')}</div>,
    },
  ];

  const socialLinks = [
    { icon: Linkedin, href: '#' },
    { icon: Twitter, href: '#' },
    { icon: Github, href: '#' },
  ];

  return (
    <section 
      id="contact" 
      className="py-20 bg-white"
      ref={ref}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isIntersecting ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-6">
            {t('contact.title')}
          </h2>
          <p className="text-xl text-black max-w-3xl mx-auto">
            {t('contact.subtitle')}
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <motion.div 
            className="space-y-8"
            initial={{ opacity: 0, x: -50 }}
            animate={isIntersecting ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="glass-effect rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-white mb-6">
                {t('contact.info.title')}
              </h3>
              
              <div className="space-y-6">
                {contactInfo.map((info, index) => (
                  <div key={index} className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                      <info.icon className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-black text-sm font-medium">{info.title}</p>
                      <div className="text-black font-semibold">
                        {info.content}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Social Links */}
            <div className="glass-effect rounded-2xl p-8">
              <h4 className="text-xl font-bold text-white mb-4">
                {t('contact.social.title')}
              </h4>
              <div className="flex space-x-4">
                {socialLinks.map((social, index) => (
                  <a
                    key={index}
                    href={social.href}
                    className="w-12 h-12 bg-white/20 hover:bg-white/30 rounded-xl flex items-center justify-center transition-colors"
                  >
                    <social.icon className="w-6 h-6 text-white" />
                  </a>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div 
            className="border border-gray-200 rounded-2xl p-8 bg-gray-50"
            initial={{ opacity: 0, x: 50 }}
            animate={isIntersecting ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <h3 className="text-2xl font-bold text-black mb-6">
              {t('contact.form.title')}
            </h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-black text-sm font-medium mb-2">
                    {t('contact.form.firstName')}
                  </label>
                  <Input
                    type="text"
                    value={formData.firstName}
                    onChange={(e) => handleInputChange('firstName', e.target.value)}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-white/40 transition-colors"
                    placeholder="John"
                    required
                  />
                </div>
                <div>
                  <label className="block text-black text-sm font-medium mb-2">
                    {t('contact.form.lastName')}
                  </label>
                  <Input
                    type="text"
                    value={formData.lastName}
                    onChange={(e) => handleInputChange('lastName', e.target.value)}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-white/40 transition-colors"
                    placeholder="Doe"
                    required
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-black text-sm font-medium mb-2">
                  {t('contact.form.email')}
                </label>
                <Input
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-white/40 transition-colors"
                  placeholder="john@example.com"
                  required
                />
              </div>
              
              <div>
                <label className="block text-black text-sm font-medium mb-2">
                  {t('contact.form.service')}
                </label>
                <Select value={formData.service} onValueChange={(value) => handleInputChange('service', value)}>
                  <SelectTrigger className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:border-white/40 transition-colors">
                    <SelectValue placeholder={t('contact.form.serviceSelect')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mobile">{t('contact.form.serviceMobile')}</SelectItem>
                    <SelectItem value="erp">{t('contact.form.serviceErp')}</SelectItem>
                    <SelectItem value="ai">{t('contact.form.serviceAi')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-black text-sm font-medium mb-2">
                  {t('contact.form.message')}
                </label>
                <Textarea
                  rows={4}
                  value={formData.message}
                  onChange={(e) => handleInputChange('message', e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-white/40 transition-colors resize-none"
                  placeholder={t('contact.form.messagePlaceholder')}
                  required
                />
              </div>
              
              <Button 
                type="submit" 
                disabled={contactMutation.isPending}
                className="w-full bg-white text-[hsl(var(--sirius-primary-900))] px-8 py-4 rounded-xl font-semibold hover:bg-gray-100 transition-colors duration-300 shadow-lg disabled:opacity-50"
              >
                {contactMutation.isPending ? 'Sending...' : t('contact.form.submit')}
              </Button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
